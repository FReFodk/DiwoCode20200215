/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React,{Component} from 'react';
import PrimaryNav from './src/components/AppNavigator';

export default class App extends Component {  
  render() {
    return (
      <PrimaryNav />
    );
  }
}
