import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Image, KeyboardAvoidingView, ActivityIndicator, Dimensions } from 'react-native';
import { TextInput, TouchableOpacity, ScrollView, } from 'react-native-gesture-handler';
import Text_EN from '../res/lang/static_text';
import LinearGradient from 'react-native-linear-gradient';
import HideWithKeyboard from 'react-native-hide-with-keyboard';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

export default class App extends Component {

    constructor(props) {
        super(props)
        this.state = {
            username: "",
        }
    }

    email_submit() {
        this.setState({ loading: true })
        var username = this.state.username;
        var data = new FormData()
        data.append('email', username);
        console.log(data);
        fetch("http://diwo.nu/public/api/forgetPassword", {
            method: 'POST',
            body: data
        })
            .then((response) => response.json())
            .then((responseJson) => {
                this.setState({ loading: false })
                if (responseJson.status == 200) {
                    alert("Mail Successfully Sent");
                    this.props.navigation.navigate('Login');
                } else {
                    alert("Invalid Credentails");
                }
            }).catch((error) => {
                console.error(error);
            });
    }

    render() {
        var { height, width } = Dimensions.get('window');
        const { navigate } = this.props.navigation;
        return (

            <KeyboardAvoidingView style={styles.container} behavior="height">
                {this.state.loading == true ? <View style={styles.spinner}>
                    <ActivityIndicator size="large" color="#12075e" />
                </View>
                    : null}
                <View style={styles.container}>
                    <Image
                        style={{ position: 'absolute', width: width * 1, height: width * 0.90, bottom: -width * 0.3, right: -width * 0.28, opacity: 0.1, transform: [{ rotate: "321deg" }] }}
                        source={require('../../uploads/diamond.png')}
                    />
                    <View style={styles.first_container}>
                        <Image
                            style={{ width: width * 0.8, height: width * 0.33 }}
                            source={require('../../uploads/Diwo_logo_txt.png')}
                        />
                    </View>
                    <View style={styles.second_container}>
                        <View>
                            <Text style={{ fontSize: width > height ? wp('2%') : wp('3.5%'), position: 'absolute', left: width > height ? wp('33%') : wp('16%'), backgroundColor: 'white', zIndex: 999, top: 5 }}> {Text_EN.Text_en.email} </Text>
                            <TextInput
                                style={styles.input}
                                autoCapitalize="none"
                                returnKeyType="next"
                                returnKeyLabel="Next"
                                placeholder="Email"
                                paddingLeft={25}
                                onChangeText={(username) => this.setState({ username })}
                            />
                        </View>
                        <LinearGradient colors={['#87d9f7', '#00a1ff']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.log_btn}>
                            <TouchableOpacity onPress={() => this.email_submit()}>
                                <Text style={{ textAlign: 'center', color: 'white', fontSize: width > height ? wp('2%') : wp('4%'), fontWeight: 'bold', borderRadius: 28, paddingTop: 15, paddingBottom: 15 }}>Submit</Text>
                            </TouchableOpacity>
                        </LinearGradient>

                        <View style={{ alignItems: 'center' }}>
                            <TouchableOpacity onPress={() => navigate('Login')}>
                                <Text style={{ fontSize: 16 }}>Login</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                    <HideWithKeyboard>
                        <View style={{ marginBottom: 14 }}>
                            {/* <Text style={{ textAlign: 'center' }}>{Text_EN.Text_en.register} <Text style={{ color: '#01a2ff', textDecorationLine: 'underline' }} onPress={() => Linking.openURL('http://diwo.nu/')}>{Text_EN.Text_en.click_here}</Text></Text> */}
                            <Text style={{ textAlign: 'center', marginTop: 0 }}><Text style={{ fontSize: 18 }}>©</Text> Copyright FReFo</Text>
                        </View>
                    </HideWithKeyboard>
                </View>
            </KeyboardAvoidingView >
        );
    }
}

var { height, width } = Dimensions.get('window');
const styles = StyleSheet.create({
    container: {
        flex: 1,
        position: 'relative',
    },
    first_container: {
        flex: 0.4,
        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: 50
    },
    second_container: {
        flex: 0.6,
        marginTop: 40,
    },
    input: {
        borderRadius: 15,
        fontSize: width > height ? wp('2%') : wp('3.5%'),
        marginVertical: 15,
        borderColor: '#01a2ff',
        borderWidth: 1.2,
        height: width > height ? wp('5%') : wp('12%'),
        width: width > height ? wp('40%') : wp('80%'),
        justifyContent: 'center',
        alignSelf: 'center',
    },
    log_btn: {
        borderRadius: 30,
        marginVertical: 15,
        width: width > height ? wp('20%') : wp('50%'),
        justifyContent: 'center',
        alignSelf: 'center',
    },
    spinner: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        justifyContent: 'center',
        zIndex: 99999,
        backgroundColor: 'grey',
        opacity: 0.8
    },
    cardview: {
        flexDirection: 'column',
        padding: 0,
        borderRadius: 15
    },
});
